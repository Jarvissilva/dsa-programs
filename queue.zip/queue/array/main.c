#include <stdio.h>
#include "header.h"

int main() {
    enqueue(2);
    enqueue(4);
    enqueue(6);

    enqueue(8);

    displayQueue();
    printf("Front element: %d\n", peekFront());  

    printf("Dequeued: %d\n", dequeue());
    printf("Dequeued: %d\n", dequeue());

    displayQueue();


    printf("Enter you input:");
    
    return 0;
}
