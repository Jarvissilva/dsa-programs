void enqueue(int val);
int dequeue();
int isFull();
int isEmpty();
void displayQueue();
int peekFront();

