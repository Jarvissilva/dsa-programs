#include <stdio.h>
#include "header.h"

#define SIZE 3 
static int queue[SIZE];
static int front = 0;
static int rear = 0;
static int count = 0;

void enqueue(int val) {
    if (isFull()) {
        printf("Queue is full\n");
    } else {
        queue[rear] = val;
        rear++;             
        count++; 
    }
}

int dequeue() {
    if (isEmpty()) {
        printf("Queue is empty\n");
        return -1;  
    } else {
        int val = queue[front];
        front++;       
        count--; 
        return val;
    }
}

int isFull() {
    return count == SIZE;
}

int isEmpty() {
    return count == 0;
}

void displayQueue() {
    if (isEmpty()) {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue elements: ");
    for (int i = 0; i < count; i++) {
        int index = (front + i) % SIZE;
        printf("%d ", queue[index]);
    }
    printf("\n");
}
int peekFront() {
    if (isEmpty()) {
        printf("Queue is empty\n");
        return -1; 
    } else {
        return queue[front];
    }
}