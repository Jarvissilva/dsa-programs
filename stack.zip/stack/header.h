void push();
void pop();
void peek();
void isFull();
void isEmpty();
