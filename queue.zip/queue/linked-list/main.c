#include <stdio.h>
#include "header.h"

int main() {
    Queue q;
    initQueue(&q);

    enqueue(&q, 10);
    enqueue(&q, 20);
    enqueue(&q, 30);

    printf("Queue after enqueuing 10, 20, 30:\n");
    displayQueue(&q);

    printf("Front element: %d\n", peekFront(&q));

    printf("Dequeued: %d\n", dequeue(&q));
    printf("Dequeued: %d\n", dequeue(&q));

    printf("Queue after dequeuing twice:\n");
    displayQueue(&q);

    printf("Front element after dequeuing: %d\n", peekFront(&q));

    enqueue(&q, 40);
    enqueue(&q, 50);

    printf("Queue after enqueuing 40 and 50:\n");
    displayQueue(&q);
    freeQueue(&q);

    return 0;
}
